# BeatShift Android starter

BeatShift is a starter Android app for selecting a video or MP3, analysing audio energy for strong beat/change points, previewing colour flashes and colour transitions, and exporting a WebM preview.

## Build with GitHub Actions
1. Upload the entire project contents to a GitHub repository (keep hidden `.github` folder).
2. Open **Actions**.
3. Select **Build BeatShift APK** and tap **Run workflow**, or push to `main`.
4. Open the successful run and download the `BeatShift-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on Android.

## Important MVP limitations
- This is a first working starter, not a full professional video editor.
- Beat detection uses audio RMS/energy peaks, so it estimates strong moments rather than understanding musical structure.
- MP3 input produces a colour visualizer edit; video input uses the video as the background with colour effects.
- Export is WebM, not MP4. Browser/WebView recording support varies by Android device. The MP3 soundtrack is not yet muxed into the exported WebM; video-source audio is attempted through WebView capture.
- For a production release, add native media rendering/muxing, MP4 export, trimming, transition controls, and device-specific testing.

## Project files
- `app/src/main/java/.../MainActivity.kt`: Android WebView shell and file picker.
- `app/src/main/assets/index.html`: UI, audio analysis, effects preview, and WebM recording.
- `.github/workflows/build.yml`: APK build workflow.
